package game;

/**
 * An enum representing the two types of player
 */
public enum Player {
    NONE,
    RED,
    BLUE
}
