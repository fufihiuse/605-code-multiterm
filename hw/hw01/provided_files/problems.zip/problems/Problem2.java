import java.util.Scanner;

public class Problem2 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int i = in.next();
		System.out.println(i);
	}
}
