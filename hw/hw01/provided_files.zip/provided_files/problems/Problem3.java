public class Problem3 {
	public static void main(String[] args) {
		int i = 5 / 0;
	}
}
