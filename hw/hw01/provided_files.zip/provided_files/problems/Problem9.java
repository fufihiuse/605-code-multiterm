public class Problem9 {
	public static void main(String[] args) {
		float sum = 0.0;
	}
}
